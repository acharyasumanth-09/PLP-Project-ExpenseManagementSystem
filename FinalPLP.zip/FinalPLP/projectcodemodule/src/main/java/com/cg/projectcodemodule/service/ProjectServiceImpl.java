package com.cg.projectcodemodule.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.projectcodemodule.bean.ProjectBean;
import com.cg.projectcodemodule.dao.IProjectDao;

@Service
public class ProjectServiceImpl implements IProjectService{
	
	@Autowired
	IProjectDao dao;

	@Override
	public ProjectBean insertProjectDetails(ProjectBean projectBean) {
		// TODO Auto-generated method stub
		return dao.insertProjectDetails(projectBean);
	}

	@Override
	public List<ProjectBean> viewProjectDetails() {
		// TODO Auto-generated method stub
		return dao.viewProjectDetails();
	}

	@Override
	public ProjectBean viewProjectDetailsByCode(String projectCode) {
		// TODO Auto-generated method stub
		return dao.viewProjectDetailsByCode(projectCode);
	}

	@Override
	public ProjectBean deleteProjectDetailsByCode(String projectCode) {
		// TODO Auto-generated method stub
		return dao.deleteProjectDetailsByCode(projectCode);
	}

	@Override
	public ProjectBean updateProjectDetails(String projectCode,
			ProjectBean projectBean) {
		// TODO Auto-generated method stub
		return dao.updateProjectDetails(projectCode,projectBean);
	}

}
