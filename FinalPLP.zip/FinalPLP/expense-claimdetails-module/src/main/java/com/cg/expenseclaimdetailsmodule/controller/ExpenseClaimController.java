package com.cg.expenseclaimdetailsmodule.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.expenseclaimdetailsmodule.bean.Employee;
import com.cg.expenseclaimdetailsmodule.bean.ExpenseModule;
import com.cg.expenseclaimdetailsmodule.bean.ProjectBean;


@RestController
@RequestMapping("/ecdm")
public class ExpenseClaimController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@RequestMapping(value = "/createExpense", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<ExpenseModule> createExpense(@RequestBody ExpenseModule expense) {
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	final String uri = "http://expensemodule/emp/create"; 
	HttpEntity<ExpenseModule> requestEntity = new HttpEntity<>(expense, requestHeaders);
		ResponseEntity<ExpenseModule> responseEntity= restTemplate.exchange(
				uri,
                HttpMethod.POST,
                requestEntity,
                ExpenseModule.class);
	    System.out.println(responseEntity);
	    return responseEntity;
	}
	
	@RequestMapping(value = "/modifyExpense/{expenseCode}", method = RequestMethod.PUT)
	public ResponseEntity<ExpenseModule> modifyExpense(@PathVariable int expenseCode,
			@RequestBody ExpenseModule ExpenseModule) {
		final String uri = "http://expensemodule/emp/update/{expenseCode}";
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	HttpEntity<ExpenseModule> requestEntity = new HttpEntity<>(ExpenseModule, requestHeaders);
		ResponseEntity<ExpenseModule> responseEntity= restTemplate.exchange(
				uri,
                HttpMethod.PUT,
                requestEntity,
                ExpenseModule.class,expenseCode);
		return responseEntity;
	}

	@RequestMapping(value = "/readExpense/{expenseCode}", method = RequestMethod.GET)
	public ExpenseModule readByExpenseCode(@PathVariable int expenseCode) {
		System.out.println("Getting School details for " + expenseCode);
		HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	    HttpEntity<ExpenseModule> requestEntity = new HttpEntity<>(requestHeaders);
		ExpenseModule response = restTemplate.exchange("http://expensemodule/emp/readById/{expenseCode}",
				HttpMethod.GET, requestEntity, new ParameterizedTypeReference<ExpenseModule>() {
				}, expenseCode).getBody();

		System.out.println("Response Received as " + response);
		return response;
	}
	
	@RequestMapping(value = "/readExpense", method = RequestMethod.GET)
	public ResponseEntity<List<ExpenseModule>> readExpense() {
	HttpHeaders requestHeaders = new HttpHeaders();
    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
    HttpEntity<ExpenseModule> requestEntity = new HttpEntity<>(requestHeaders);
    final String uri = "http://expensemodule/emp/read"; 
    ResponseEntity<List<ExpenseModule>>list = restTemplate.exchange(uri,
            HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<ExpenseModule>>() {
    });
	return list;
	}
	
	@RequestMapping(value = "/deleteExpense/{expenseCode}", method = RequestMethod.DELETE)
	public String deleteExpense(@PathVariable int expenseCode) {
		HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	    HttpEntity<ExpenseModule> requestEntity = new HttpEntity<>(requestHeaders);
		restTemplate.exchange("http://expensemodule/emp/delete/{expenseCode}",
				HttpMethod.DELETE, requestEntity, new ParameterizedTypeReference<String>() {
				}, expenseCode).getBody();
		return "Deleted";
	}
	/*@RequestMapping(value = "/deleteExpense/{expenseCode}", method = RequestMethod.DELETE)
	public String deleteExpense(
			@PathVariable int expenseCode) {
		final String uri = "http://localhost:8102/ecm/delete/{expenseCode}";
		RestTemplate restTemplate = new RestTemplate();
	restTemplate.delete(uri,	expenseCode);
		return "Delete Success";*/

	/*@RequestMapping(value = "/createExpense1", method = RequestMethod.POST)
	public ExpenseModule createExpense1(
			@RequestBody ExpenseModule ExpenseModule) {
		final String uri = "http://localhost:4445/create";
		RestTemplate restTemplate = new RestTemplate();
		ExpenseModule details = restTemplate.postForObject(uri,
				ExpenseModule, ExpenseModule.class);
		return details;
	}
	*/
	
	
	/*@RequestMapping(value = "/readExpense", method = RequestMethod.GET)
	public List<ExpenseModule> readExpense() {
		final String uri = "http://localhost:8102/ecm/readExpense";
		RestTemplate restTemplate = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<ExpenseModule> details = restTemplate.getForObject(uri, List.class);
		return details;
	}*/
	
	/*@RequestMapping(value = "/readExpense/{expenseCode}", method = RequestMethod.GET)
	public ExpenseModule readByExpenseCode(@PathVariable int expenseCode) {
		final String uri = "http://localhost:8102/ecm/read/{expenseCode}";
		RestTemplate restTemplate = new RestTemplate();
		ExpenseModule details = restTemplate.getForObject(uri, ExpenseModule.class, expenseCode);
		return details;
	}*/
	
	/*@RequestMapping(value = "/modifyExpense/{expenseCode}", method = RequestMethod.PUT)
	public ExpenseModule modifyExpense(@PathVariable int expenseCode,
			@RequestBody ExpenseModule ExpenseModule) {
		final String uri = "http://localhost:8102/ecm/update/{expenseCode}";
		RestTemplate restTemplate = new RestTemplate();
		ExpenseModule.setExpenseCode(expenseCode);
		restTemplate.put(uri, ExpenseModule, expenseCode);
		return ExpenseModule;
	}*/
	
	/*@RequestMapping(value = "/deleteExpense/{expenseCode}", method = RequestMethod.DELETE)
	public String deleteExpense(
			@PathVariable int expenseCode) {
		final String uri = "http://localhost:8102/ecm/delete/{expenseCode}";
		RestTemplate restTemplate = new RestTemplate();
	restTemplate.delete(uri,	expenseCode);
		return "Delete Success";
	}*/
	
	@RequestMapping(value = "/createEmployee", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	final String uri = "http://EmployeeIndu/insert"; 
	HttpEntity<Employee> requestEntity = new HttpEntity<>(employee, requestHeaders);
		ResponseEntity<Employee> responseEntity= restTemplate.exchange(
				uri,
                HttpMethod.POST,
                requestEntity,
                Employee.class);
	    return responseEntity;
	}
	
	

	/*@RequestMapping(value = "/createEmployee", method = RequestMethod.POST)
	public Employee createEmployee1(@RequestBody Employee employee) {
		final String uri = "http://localhost:9000/employee/create";
		RestTemplate restTemplate = new RestTemplate();
		Employee details = restTemplate.postForObject(uri, employee,
				Employee.class);
		return details;
	}*/
	
	@RequestMapping(value = "/readEmployee", method = RequestMethod.GET)
	public ResponseEntity<List<Employee>> readEmployee() {
	HttpHeaders requestHeaders = new HttpHeaders();
    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
    HttpEntity<ExpenseModule> requestEntity = new HttpEntity<>(requestHeaders);
    final String uri = "http://EmployeeIndu/view"; 
    ResponseEntity<List<Employee>>list = restTemplate.exchange(uri,
            HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<Employee>>() {
    });
	return list;
	}

	/*@RequestMapping(value = "/readEmployee", method = RequestMethod.GET)
	public List<Employee> readEmployee() {
		final String uri = "http://localhost:9000/employee/readall";
		RestTemplate restTemplate = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<Employee> details = restTemplate.getForObject(uri, List.class);
		return details;
	}*/

	@RequestMapping(value = "/modifyEmployee/{employeeId}", method = RequestMethod.PUT)
	public ResponseEntity<Employee> modifyExpense(@PathVariable String employeeId,
			@RequestBody Employee employee) {
		final String uri = "http://EmployeeIndu/update/{employeeId}";
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	HttpEntity<Employee> requestEntity = new HttpEntity<>(employee, requestHeaders);
		ResponseEntity<Employee> responseEntity= restTemplate.exchange(
				uri,
                HttpMethod.PUT,
                requestEntity,
                Employee.class,employeeId);
		return responseEntity;
	}

	
	/*@RequestMapping(value = "/modifyEmployee/{employeeId}", method = RequestMethod.PUT)
	public Employee updateData(@PathVariable String employeeId,
			@RequestBody Employee employee) {
		final String uri = "http://localhost:9000/employee/modify/{employeeId}";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put(uri, employee, employeeId);
		return employee;

	}*/

	@RequestMapping(value = "/deleteEmployee/{employeeId}", method = RequestMethod.DELETE)
	public String deleteData(@PathVariable String employeeId) {
		HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	    HttpEntity<Employee> requestEntity = new HttpEntity<>(requestHeaders);
		restTemplate.exchange("http://EmployeeIndu/delete/{employeeId}",
				HttpMethod.DELETE, requestEntity, new ParameterizedTypeReference<String>() {
				}, employeeId).getBody();
		return "Deleted";
	}
	
	
	
	/*@RequestMapping(value = "/deleteEmployee/{employeeId}", method = RequestMethod.DELETE)
	public String deleteData(@PathVariable String employeeId) {
		final String uri = "http://localhost:9000/employee/delete/{employeeId}";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete(uri, employeeId);
		return " happy??? deleted :-(";

	}*/

	@RequestMapping(value = "/readEmployee/{employeeId}", method = RequestMethod.GET)
	public Employee readByEmployeeId(@PathVariable String employeeId) {
		HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	    HttpEntity<Employee> requestEntity = new HttpEntity<>(requestHeaders);
		Employee response = restTemplate.exchange("http://EmployeeIndu/viewbyID/{employeeId}",
				HttpMethod.GET, requestEntity, new ParameterizedTypeReference<Employee>() {
				}, employeeId).getBody();
		return response;
	}
	
	
	/*@RequestMapping(value = "/readEmployee/{employeeId}", method = RequestMethod.GET)
	public Employee readData(@PathVariable String employeeId) {
		final String uri = "http://localhost:9000/employee/read/{employeeId}";
		RestTemplate restTemplate = new RestTemplate();
		Employee employee = restTemplate.getForObject(uri, Employee.class, employeeId);
		return employee;
	}*/
	
/*	@RequestMapping(value = "/createProjectBean", method = RequestMethod.POST)
	public ProjectBean createProjectBean(@RequestBody ProjectBean ProjectBean) {
		final String uri = "http://localhost:4446/create";
		RestTemplate restTemplate = new RestTemplate();
		ProjectBean details = restTemplate.postForObject(uri, ProjectBean,
				ProjectBean.class);
		return details;
	}
	*/@RequestMapping(value = "/createproject", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<ProjectBean> createProject(@RequestBody ProjectBean projectBean) {
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	final String uri = "http://projectmodule/project/create"; 
	HttpEntity<ProjectBean> requestEntity = new HttpEntity<>(projectBean, requestHeaders);
		ResponseEntity<ProjectBean> responseEntity= restTemplate.exchange(
				uri,
                HttpMethod.POST,
                requestEntity,
                ProjectBean.class);
	    System.out.println(responseEntity);
	    return responseEntity;
	}
	
	/*@RequestMapping(value = "/readAllProjectBean", method = RequestMethod.GET)
	public List<ProjectBean> readAllProjectBean() {
		final String uri = "http://localhost:4446/view";
		RestTemplate restTemplate = new RestTemplate();
		@SuppressWarnings("unchecked")
		List<ProjectBean> details = restTemplate.getForObject(uri,List.class);
		return details;
	}
	*/
	/*@RequestMapping(value = "/readProjectBeanById/{projectCode}", method = RequestMethod.GET)
	public ProjectBean readProjectBeanById(@PathVariable int projectCode) {
		final String uri = "http://localhost:4446/viewByCode/{projectCode}";
		RestTemplate restTemplate = new RestTemplate();
		ProjectBean details = restTemplate.getForObject(uri,ProjectBean.class,projectCode);
		return details;
	}
	
	@RequestMapping(value = "/updateProjectBeanById/{id}", method = RequestMethod.PUT)
	public ProjectBean updateProjectBeanById(@PathVariable String id,@RequestBody ProjectBean ProjectBean) {
		final String uri = "http://localhost:4446/update/{projectCode}";
		ProjectBean.setProjectCode(id);
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put(uri,ProjectBean.class,id);
		return ProjectBean;
	}
	
	@RequestMapping(value = "/deleteProjectBeanById/{id}", method = RequestMethod.DELETE)
	public String deleteProjectBeanById(@PathVariable int id) {
		final String uri = "http://localhost:4446/deleteByCode/{projectCode}";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put(uri,ProjectBean.class,id);
		return "Delete Success";
	}*/

	@RequestMapping(value = "/readProject/{projectCode}", method = RequestMethod.GET)
	public ProjectBean readByProjectId(@PathVariable String projectCode) {
		HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	    HttpEntity<ProjectBean> requestEntity = new HttpEntity<>(requestHeaders);
	    ProjectBean response = restTemplate.exchange("http://projectmodule/project/viewByCode/{projectCode}",
				HttpMethod.GET, requestEntity, new ParameterizedTypeReference<ProjectBean>() {
				}, projectCode).getBody();
		return response;
	}
	
	@RequestMapping(value = "/deleteProject/{projectCode}", method = RequestMethod.DELETE)
	public String deleteProjectData(@PathVariable String projectCode) {
		HttpHeaders requestHeaders = new HttpHeaders();
	    requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
	    HttpEntity<ProjectBean> requestEntity = new HttpEntity<>(requestHeaders);
		restTemplate.exchange("http://projectmodule/project/deleteByCode/{projectCode}",
				HttpMethod.DELETE, requestEntity, new ParameterizedTypeReference<String>() {
				}, projectCode).getBody();
		return "Deleted";
	}
	
	@RequestMapping(value = "/modifyProject/{projectCode}", method = RequestMethod.PUT)
	public ResponseEntity<ProjectBean> modifyProject(@PathVariable String projectCode,
			@RequestBody ProjectBean projectBean) {
		final String uri = "http://projectmodule/project/update/{projectCode}";
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	HttpEntity<ProjectBean> requestEntity = new HttpEntity<>(projectBean, requestHeaders);
		ResponseEntity<ProjectBean> responseEntity= restTemplate.exchange(
				uri,
                HttpMethod.PUT,
                requestEntity,
                ProjectBean.class,projectCode);
		return responseEntity;
	}
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	
}
