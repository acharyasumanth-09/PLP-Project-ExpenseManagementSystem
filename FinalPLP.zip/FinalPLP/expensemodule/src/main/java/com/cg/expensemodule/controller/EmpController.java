package com.cg.expensemodule.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.expensemodule.bean.ExpenseModule;
import com.cg.expensemodule.service.IExpenseService;

@RestController
@RequestMapping("/emp")
public class EmpController {
	@Autowired
	IExpenseService service;
	/*EmpRepository repository;*/
	
	@RequestMapping(value = "/create",method=RequestMethod.POST)
    public ExpenseModule createExpenseModule(@Valid @RequestBody ExpenseModule expense) {
        return service.createExpenseModule(expense);
    }
	
	@RequestMapping(value="/read",method=RequestMethod.GET)
	public List<ExpenseModule> readExpenseModule()
	{
		return service.readExpenseModule();
	}
	
	@RequestMapping(value="/readById/{expenseCode}",method=RequestMethod.GET)
	public ExpenseModule readExpenseModuleById(@PathVariable String expenseCode)
	{
		return service.readExpenseModuleById(expenseCode);
	}
	
	@RequestMapping(value="/delete/{expenseCode}",method=RequestMethod.DELETE)
	public ExpenseModule deleteExpenseModule(@PathVariable String expenseCode)
	{
		return service.deleteExpenseModule(expenseCode);
	}
	
	@RequestMapping(value="/update/{expenseCode}",method=RequestMethod.PUT)
	public ExpenseModule updateExpenseModule(@PathVariable String expenseCode,@RequestBody ExpenseModule expenseModule)
	{
		return service.updateExpenseModule(expenseCode,expenseModule);
	}
	
	

}
